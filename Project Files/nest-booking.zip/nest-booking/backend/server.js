const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());

let bookings = [];

app.post("/bookings", (req, res) => {
  const booking = req.body;
  bookings.push(booking);
  console.log("✅ New Booking:", booking);
  res.status(200).send({ message: "Booking successful!" });
});

app.get("/bookings", (req, res) => {
  res.send(bookings);
});

app.listen(PORT, () => {
  console.log("Server running at http://localhost:" + PORT);
});
document.getElementById("bookingForm").addEventListener("submit", async function (e) {
  e.preventDefault();

  const data = {
    name: e.target.name.value,
    email: e.target.email.value,
    address: e.target.address.value,
    quantity: e.target.quantity.value
  };

  const response = await fetch("http://localhost:3000/bookings", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(data)
  });

  if (response.ok) {
    alert("Booking successful!");
    e.target.reset();
  } else {
    alert("Booking failed.");
  }
});